#!/bin/sh
java -cp ../lib/* Fire.java 
