#!/bin/sh
java -cp ../lib/* Crazy.java 
